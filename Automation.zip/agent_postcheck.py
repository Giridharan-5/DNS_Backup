import subprocess
from config import DNS_SERVER_PRIMARY as DNS_SERVER, DOMAIN

def postcheck_domain():
    try:
        result = subprocess.run(
            ["dig", f"@{DNS_SERVER}", DOMAIN, "+short"],
            capture_output=True,
            text=True,
            check=True
        )
        output = result.stdout.strip()
        if output:
            return True, f"Domain exists after update: {output}"
        else:
            return False, "Domain still does not exist after update"
    except subprocess.CalledProcessError as e:
        return False, f"Postcheck failed: {e}"
