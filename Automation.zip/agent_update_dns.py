import re
import subprocess
from config import ZONE_FILE, DOMAIN, IP_ADDRESS

def update_dns():
    try:
        # Read zone file
        with open(ZONE_FILE, "r") as f:
            lines = f.readlines()

        # Increment SOA serial
        for i, line in enumerate(lines):
            if "SOA" in line:
                match = re.search(r"(\d{10})", line)
                if match:
                    serial = int(match.group(1))
                    serial += 1
                    lines[i] = line.replace(match.group(1), str(serial))
                    break

        # Update or add A record
        domain_exists = False
        for i, line in enumerate(lines):
            if line.startswith(DOMAIN.split('.')[0]):
                lines[i] = f"{DOMAIN.split('.')[0]} IN A {IP_ADDRESS}\n"
                domain_exists = True
                break
        if not domain_exists:
            lines.append(f"{DOMAIN.split('.')[0]} IN A {IP_ADDRESS}\n")

        # Write back zone file
        with open(ZONE_FILE, "w") as f:
            f.writelines(lines)

        # Check zone syntax
        check = subprocess.run(
            ["named-checkzone", "mfg-itis.tcs", ZONE_FILE],
            capture_output=True,
            text=True
        )
        if "OK" not in check.stdout:
            return False, f"Zone check failed: {check.stdout}"

        # Reload BIND
        subprocess.run(["sudo", "systemctl", "reload", "bind9"], check=True)

        return True, "DNS record added/updated and BIND reloaded"
    except Exception as e:
        return False, f"DNS update failed: {e}"
