# DNS Server configuration
DNS_SERVER_PRIMARY = "dns1.mfg-itis.tcs"   # Primary DNS server
DNS_SERVER_SECONDARY = "dns2.mfg-itis.tcs" # Secondary DNS server
ZONE_FILE = "/etc/bind/db.mfg-itis.tcs"    # Path to your BIND zone file

# Domain & IP to update
DOMAIN = "marvel.mfg-itis.tcs"
IP_ADDRESS = "10.0.0.50"  # The IP you want to assign to the domain
