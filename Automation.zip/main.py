from agent_precheck import precheck_domain
from agent_update_dns import update_dns
from agent_postcheck import postcheck_domain

def run_agents():
    summary = {}

    # Pre-check
    pre_status, pre_msg = precheck_domain()
    summary['Pre-check'] = pre_msg
    print(f"Pre-check: {pre_msg}")

    # Update (only if domain does not exist)
    if not pre_status:
        upd_status, upd_msg = update_dns()
    else:
        upd_status, upd_msg = True, "Domain already exists, no update needed"
    summary['Update'] = upd_msg
    print(f"Update: {upd_msg}")

    # Post-check
    post_status, post_msg = postcheck_domain()
    summary['Post-check'] = post_msg
    print(f"Post-check: {post_msg}")

    # Overall status
    summary['Status'] = "SUCCESS" if post_status else "FAILED"
    print(f"Status: {summary['Status']}")

    return summary

if __name__ == "__main__":
    run_agents()
