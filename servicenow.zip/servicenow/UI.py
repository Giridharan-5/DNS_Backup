import streamlit as st
import pandas as pd
from datetime import datetime

# Agents
from agent_servicenow import fetch_tickets
from graph import process_ticket
from agent_ticket_intelligence import analyze_ticket

# -----------------------------------------------------
# PAGE CONFIG
# -----------------------------------------------------
st.set_page_config(
    page_title="DNS Automation Control Panel",
    layout="wide",
    initial_sidebar_state="expanded"
)

# -----------------------------------------------------
# SESSION STATE INIT
# -----------------------------------------------------
if "fetched_tickets" not in st.session_state:
    st.session_state.fetched_tickets = []

if "resolved_tickets" not in st.session_state:
    st.session_state.resolved_tickets = []

if "failed_tickets" not in st.session_state:
    st.session_state.failed_tickets = []

if "current_index" not in st.session_state:
    st.session_state.current_index = 0

if "last_output" not in st.session_state:
    st.session_state.last_output = None
    
if "resolver_ran" not in st.session_state:
    st.session_state.resolver_ran = False

# -----------------------------------------------------
# SIDEBAR NAVIGATION
# -----------------------------------------------------
st.sidebar.title("🧠 DNS Automation")

menu = st.sidebar.radio(
    "Navigation",
    [
        "Project Overview",
        "Fetched Tickets",
        "Resolved Tickets",
        "Failed Tickets"
    ]
)

# -----------------------------------------------------
# PROJECT OVERVIEW
# -----------------------------------------------------
if menu == "Project Overview":

    st.title("🚀 Enterprise DNS Automation Platform")

    st.markdown("""
    ### 🔎 Project Definition

    This platform automates DNS change management using:
    
    - 🧠 LLM-based ticket intelligence  
    - ⚙️ LangGraph multi-agent orchestration  
    - 🔐 Secure SSH-based DNS updates  
    - 🔁 Precheck & Postcheck validation  
    - 📋 Automated ServiceNow resolution  

    The system ensures:
    
    - Safe DNS ADD / UPDATE / DELETE execution  
    - Destructive request blocking  
    - Real-time validation  
    - Full audit traceability  
    """)

# -----------------------------------------------------
# FETCHED TICKETS PAGE
# -----------------------------------------------------
elif menu == "Fetched Tickets":

    st.title("📥 Fetched Open Tickets")

    if st.button("Fetch Open Tickets from ServiceNow"):
        with st.spinner("Fetching tickets..."):
            tickets = fetch_tickets()
            st.session_state.fetched_tickets = tickets
            st.session_state.current_index = 0
            st.session_state.last_output = None
            st.session_state.resolver_ran = False
            st.success(f"{len(tickets)} open tickets fetched.")

    tickets = st.session_state.fetched_tickets

    if tickets:

        st.info(f"Total Open Tickets: {len(tickets)}")

        df = pd.DataFrame(tickets)[["number", "short_description"]]
        st.dataframe(df, use_container_width=True)

        # -------------------------------------------------
        # DNS RESOLVER STEP-BY-STEP
        # -------------------------------------------------
        if st.session_state.current_index < len(tickets):

            ticket = tickets[st.session_state.current_index]

            st.markdown("---")
            st.subheader(f"Next Ticket: {ticket['number']}")

            if st.button(
                "⚙️ Run DNS Resolver",
                disabled=st.session_state.resolver_ran
            ):

                st.session_state.resolver_ran = True
                st.session_state.last_output = None

                with st.spinner("Processing ticket..."):
                    number, output = process_ticket(ticket)

                st.session_state.last_output = output

                analysis = analyze_ticket(
                    ticket.get("short_description", ""),
                    ticket.get("description", "")
                )

                classification = analysis.get("classification", "UNKNOWN")

                if "NOT resolved" in output:
                    st.session_state.failed_tickets.append({
                        "ticket": ticket,
                        "output": output
                    })
                else:
                    st.session_state.resolved_tickets.append({
                        "ticket": ticket,
                        "output": output
                    })

                st.success("Processing completed.")

            if st.session_state.last_output:
                st.code(st.session_state.last_output)

                if st.button("➡ Next Ticket"):
                    st.session_state.last_output = None
                    st.session_state.resolver_ran = False
                    st.session_state.current_index += 1
                    st.rerun()

        else:
            st.success("All tickets processed.")

    else:
        st.warning("No unresolved tickets found.")

# -----------------------------------------------------
# RESOLVED TICKETS PAGE
# -----------------------------------------------------
elif menu == "Resolved Tickets":

    st.title("✅ Resolved Tickets")

    resolved = st.session_state.resolved_tickets

    if not resolved:
        st.info("No resolved tickets yet.")
    else:
        numbers = [r["ticket"]["number"] for r in resolved]
        selected = st.selectbox("Select Ticket", numbers)

        selected_ticket = next(
            r for r in resolved if r["ticket"]["number"] == selected
        )

        st.subheader(f"Ticket: {selected}")
        st.markdown("### 📝 Agent Execution Output")
        st.code(selected_ticket["output"])

        st.markdown("### 📋 ServiceNow Resolution Status")

        ticket_data = selected_ticket["ticket"]

        st.write(f"**Incident State:** {ticket_data.get('incident_state')}")
        st.write("**Status:** Resolved in ServiceNow")

# -----------------------------------------------------
# FAILED TICKETS PAGE
# -----------------------------------------------------
elif menu == "Failed Tickets":

    st.title("❌ Failed Tickets")

    failed = st.session_state.failed_tickets

    if not failed:
        st.info("No failed tickets.")
    else:
        numbers = [r["ticket"]["number"] for r in failed]
        selected = st.selectbox("Select Ticket", numbers)

        selected_ticket = next(
            r for r in failed if r["ticket"]["number"] == selected)

        st.subheader(f"Ticket: {selected}")
        st.markdown("### 📝 Agent Execution Output")
        st.code(selected_ticket["output"])

        st.markdown("### ⚠️ Status")
        st.error("Ticket failed to resolve automatically.")