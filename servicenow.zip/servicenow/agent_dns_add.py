import subprocess
import re

DNSMASQ_FILE = "/etc/dnsmasq.d/custom-dns.conf"

# ---- REMOTE DNS SERVER DETAILS ----
from config import (
    DNS_SERVER_IP,
    DNS_SERVER_USER,
    DNS_ZONE_FILE,
    DNS_ZONE_NAME,
    SSH_KEY
)


def _valid_domain(d):
    return re.fullmatch(
        r"(?!-)([a-zA-Z0-9-]{1,63}\.)+[a-zA-Z]{2,}",
        d
    )


def _valid_ip(i):
    return re.fullmatch(
        r"(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)"
        r"(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}",
        i
    )


# -----------------------------
# UPDATE REAL DNS SERVER VIA SSH
# -----------------------------
def _add_record_to_bind_via_ssh(domain: str, ip: str):
    if domain.endswith(f".{DNS_ZONE_NAME}"):
        record_name = domain.replace(f".{DNS_ZONE_NAME}", "")
    else:
        record_name = domain

    ssh_cmd = f"""
SERIAL=$(date +%Y%m%d%H)
# Remove existing A record for this hostname
sudo sed -i '/^{record_name} IN A/d' {DNS_ZONE_FILE} &&
# Update serial
sudo sed -i "s/[0-9]\\{{10\\}}/$SERIAL/" {DNS_ZONE_FILE} &&
# Add new A record
echo "{record_name} IN A {ip}" | sudo tee -a {DNS_ZONE_FILE} >/dev/null &&
# Validate zone
sudo named-checkzone {DNS_ZONE_NAME} {DNS_ZONE_FILE} &&
# Reload BIND
sudo systemctl reload bind9 &&
# Wait a second to allow propagation
sleep 1
"""

    subprocess.run(
        [
            "ssh",
            "-i", SSH_KEY,
            "-o", "BatchMode=yes",
            "-o", "StrictHostKeyChecking=no",
            f"{DNS_SERVER_USER}@{DNS_SERVER_IP}",
            ssh_cmd
        ],
        check=True
    )



# -----------------------------
# MAIN ADD FUNCTION
# -----------------------------
def add_dns(domain: str, ip: str):
    if not _valid_domain(domain):
        return False, "Invalid domain"
    if not _valid_ip(ip):
        return False, "Invalid IP"

    record = f"address=/{domain}/{ip}"

    try:
        # ---------------- dnsmasq CHECK ----------------
        subprocess.run(
            ["sudo", "test", "-f", DNSMASQ_FILE],
            check=False
        )

        result = subprocess.run(
            ["sudo", "grep", "-F", record, DNSMASQ_FILE],
            capture_output=True,
            text=True
        )

        record_exists = result.returncode == 0

        if record_exists:
            print("[INFO] DNS record exists in dnsmasq, skipping append")
        else:
            subprocess.run(
                ["sudo", "tee", "-a", DNSMASQ_FILE],
                input=record + "\n",
                text=True,
                check=True
            )

        subprocess.run(["sudo", "dnsmasq", "--test"], check=True)
        subprocess.run(["sudo", "systemctl", "restart", "dnsmasq"], check=True)
        subprocess.run(["sudo", "killall", "-HUP", "dnsmasq"], check=True)

        # ---------------- REAL DNS SERVER ADD ----------------
        _add_record_to_bind_via_ssh(domain, ip)

        return True, f"Added DNS record {domain} → {ip} (dnsmasq + BIND)"

    except Exception as e:
        return False, str(e)
