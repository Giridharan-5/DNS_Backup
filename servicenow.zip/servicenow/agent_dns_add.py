import subprocess
import re

DNSMASQ_FILE = "/etc/dnsmasq.d/custom-dns.conf"

def _valid_domain(d): 
    return re.fullmatch(r"[a-zA-Z0-9.-]+", d)

def _valid_ip(i): 
    return re.fullmatch(r"(?:\d{1,3}\.){3}\d{1,3}", i)

def add_dns(domain: str, ip: str):
    if not _valid_domain(domain):
        return False, "Invalid domain"
    if not _valid_ip(ip):
        return False, "Invalid IP"

    record = f"address=/{domain}/{ip}\n"

    try:
        # Ensure file exists
        open(DNSMASQ_FILE, "a").close()

        # Remove existing record for this domain (avoid duplicates)
        with open(DNSMASQ_FILE, "r") as f:
            lines = f.readlines()

        cleaned = [l for l in lines if not l.startswith(f"address=/{domain}/")]

        cleaned.append(record)

        with open(DNSMASQ_FILE, "w") as f:
            f.writelines(cleaned)

        # Validate dnsmasq config
        subprocess.run(["dnsmasq", "--test"], check=True)

        # Restart dnsmasq
        subprocess.run(["systemctl", "restart", "dnsmasq"], check=True)

        # Flush dnsmasq cache
        subprocess.run(["killall", "-HUP", "dnsmasq"], check=True)

        return True, f"Added DNS record {domain} → {ip}"

    except Exception as e:
        return False, str(e)
