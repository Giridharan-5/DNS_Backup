import subprocess
import re

DNSMASQ_FILE = "/etc/dnsmasq.d/custom-dns.conf"

def _valid_domain(d): return re.fullmatch(r"[a-zA-Z0-9.-]+", d)
def _valid_ip(i): return re.fullmatch(r"(?:\d{1,3}\.){3}\d{1,3}", i)

def add_dns(domain: str, ip: str):
    if not _valid_domain(domain):
        return False, "Invalid domain"
    if not _valid_ip(ip):
        return False, "Invalid IP"

    record = f"address=/{domain}/{ip}\n"

    try:
        with open(DNSMASQ_FILE, "a") as f:
            f.write(record)

        subprocess.run(["dnsmasq", "--test"], check=True)
        subprocess.run(["systemctl", "restart", "dnsmasq"], check=True)

        return True, f"Added {domain} → {ip}"
    except Exception as e:
        return False, str(e)
