import subprocess

DNSMASQ_FILE = "/etc/dnsmasq.d/custom-dns.conf"

def delete_dns(domain: str):
    try:
        with open(DNSMASQ_FILE) as f:
            lines = f.readlines()

        new = [l for l in lines if domain not in l]

        if len(lines) == len(new):
            return False, "Domain not found"

        with open(DNSMASQ_FILE, "w") as f:
            f.writelines(new)

        subprocess.run(["sudo", "systemctl", "restart", "dnsmasq"], check=True)
        return True, f"Deleted {domain}"
    except Exception as e:
        return False, str(e)
