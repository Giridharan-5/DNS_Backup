import subprocess
import re

DNSMASQ_FILE = "/etc/dnsmasq.d/custom-dns.conf"

from config import (
    DNS_SERVER_IP,
    DNS_SERVER_USER,
    DNS_ZONE_FILE,
    DNS_ZONE_NAME,
    SSH_KEY
)

# -----------------------------
# DELETE RECORD FROM REAL DNS SERVER VIA SSH
# -----------------------------
def _delete_record_via_ssh(domain: str):
    record_name = domain.replace(f".{DNS_ZONE_NAME}", "")

    ssh_cmd = f"""
SERIAL=$(date +%Y%m%d%H)
sudo sed -i '/^{record_name} IN A/d' {DNS_ZONE_FILE} &&
sudo sed -i "s/[0-9]\\{{10\\}}/$SERIAL/" {DNS_ZONE_FILE} &&
sudo named-checkzone {DNS_ZONE_NAME} {DNS_ZONE_FILE} &&
sudo systemctl reload bind9
"""


    subprocess.run(
        [
            "ssh",
            "-i", SSH_KEY,
            "-o", "BatchMode=yes",
            "-o", "StrictHostKeyChecking=no",
            f"{DNS_SERVER_USER}@{DNS_SERVER_IP}",
            ssh_cmd
        ],
        check=True
    )


# -----------------------------
# DOMAIN VALIDATION
# -----------------------------
def _valid_domain(d):
    return bool(re.fullmatch(
        r"(?!-)[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+",
        d
    ))


# -----------------------------
# DELETE DNS (DNSMASQ + BIND)
# -----------------------------
def delete_dns(domain: str):
    if not _valid_domain(domain):
        return False, "Invalid domain"

    try:
        record_prefix = f"address=/{domain}/"

        # Check if record exists
        result = subprocess.run(
            ["sudo", "grep", "-F", record_prefix, DNSMASQ_FILE],
            capture_output=True,
            text=True
        )

        if result.returncode != 0:
            return False, "Domain not found"

        # Delete record from dnsmasq
        subprocess.run(
            [
                "sudo",
                "sed",
                "-i",
                f"\\|^{record_prefix}|d",
                DNSMASQ_FILE
            ],
            check=True
        )

        # Validate dnsmasq config
        subprocess.run(["sudo", "dnsmasq", "--test"], check=True)

        # Restart dnsmasq
        subprocess.run(["sudo", "systemctl", "restart", "dnsmasq"], check=True)

        # Flush dnsmasq cache
        subprocess.run(["sudo", "killall", "-HUP", "dnsmasq"], check=True)

        # ---------------- REAL DNS SERVER DELETE ----------------
        _delete_record_via_ssh(domain)

        return True, f"Deleted DNS record for {domain} (dnsmasq + BIND)"

    except Exception as e:
        return False, str(e)
