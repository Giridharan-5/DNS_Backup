import subprocess

DNSMASQ_FILE = "/etc/dnsmasq.d/custom-dns.conf"

def delete_dns(domain: str):
    try:
        # Ensure file exists
        open(DNSMASQ_FILE, "a").close()

        with open(DNSMASQ_FILE, "r") as f:
            lines = f.readlines()

        # Remove only exact domain record
        new_lines = [
            l for l in lines
            if not l.startswith(f"address=/{domain}/")
        ]

        if len(lines) == len(new_lines):
            return False, "Domain not found"

        with open(DNSMASQ_FILE, "w") as f:
            f.writelines(new_lines)

        # Validate dnsmasq config
        subprocess.run(["dnsmasq", "--test"], check=True)

        # Restart dnsmasq
        subprocess.run(["systemctl", "restart", "dnsmasq"], check=True)

        # Flush dnsmasq cache
        subprocess.run(["killall", "-HUP", "dnsmasq"], check=True)

        return True, f"Deleted DNS record for {domain}"

    except Exception as e:
        return False, str(e)
