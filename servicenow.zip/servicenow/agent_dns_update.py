import subprocess
import re
import os

from config import (
    DNS_SERVER_IP,
    DNS_SERVER_USER,
    DNS_ZONE_FILE,
    DNS_ZONE_NAME,
    SSH_KEY
)

SSH_KEY = os.path.expanduser(SSH_KEY)


def _valid_domain(domain: str) -> bool:
    return bool(re.fullmatch(
        r"(?!-)[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+",
        domain
    ))


def _valid_ip(ip: str) -> bool:
    return bool(re.fullmatch(
        r"(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)"
        r"(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}",
        ip
    ))


def update_dns(domain: str, ip: str):
    if not _valid_domain(domain):
        return False, "Invalid domain"

    if not _valid_ip(ip):
        return False, "Invalid IP address"

    record_name = domain.replace(f".{DNS_ZONE_NAME}", "")

    ssh_cmd = f"""
# Extract current serial safely (works for both single-line & multi-line SOA)
CURRENT_SERIAL=$(sudo grep -Eo '[0-9]{{10}}' {DNS_ZONE_FILE} | head -1)

# Increment serial safely
if [[ "$CURRENT_SERIAL" =~ ^[0-9]+$ ]]; then
    NEW_SERIAL=$((CURRENT_SERIAL + 1))
else
    NEW_SERIAL=$(date +%Y%m%d01)
fi

# Remove old A record
sudo sed -i '/^{record_name} IN A/d' {DNS_ZONE_FILE}

# Replace serial ONLY if found
if [ -n "$CURRENT_SERIAL" ]; then
    sudo sed -i "0,/$CURRENT_SERIAL/s//$NEW_SERIAL/" {DNS_ZONE_FILE}
fi

# Add new A record
echo "{record_name} IN A {ip}" | sudo tee -a {DNS_ZONE_FILE} >/dev/null

# Validate zone silently
sudo named-checkzone {DNS_ZONE_NAME} {DNS_ZONE_FILE} >/dev/null 2>&1

# Reload BIND silently
sudo systemctl reload bind9 >/dev/null 2>&1
"""

    try:
        subprocess.run(
            [
                "ssh",
                "-i", SSH_KEY,
                "-o", "BatchMode=yes",
                "-o", "StrictHostKeyChecking=no",
                f"{DNS_SERVER_USER}@{DNS_SERVER_IP}",
                ssh_cmd
            ],
            check=True
        )

        return True, f"DNS record updated for {domain} → {ip}"

    except subprocess.CalledProcessError as e:
        return False, f"DNS UPDATE failed: {e}"