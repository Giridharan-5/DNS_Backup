import os
import subprocess
import re

DNSMASQ_CONF = "/etc/dnsmasq.d/custom-dns.conf"
BIND_ZONE = "/etc/bind/db.mfg-itis.tcs"
ZONE_NAME = "mfg-itis.tcs"

USE_DNSMASQ = os.path.exists(DNSMASQ_CONF)

def _valid_domain(d): 
    return re.fullmatch(r"[a-zA-Z0-9.-]+", d)

def _valid_ip(i): 
    return re.fullmatch(r"(?:\d{1,3}\.){3}\d{1,3}", i)

def update_dns(domain: str, ip: str):
    if not _valid_domain(domain) or not _valid_ip(ip):
        return False, "Invalid input"

    try:
        if USE_DNSMASQ:
            record = f"address=/{domain}/{ip}\n"

            # Ensure file exists
            open(DNSMASQ_CONF, "a").close()

            # Remove old record
            with open(DNSMASQ_CONF, "r") as f:
                lines = f.readlines()

            cleaned = [
                l for l in lines
                if not l.startswith(f"address=/{domain}/")
            ]

            cleaned.append(record)

            with open(DNSMASQ_CONF, "w") as f:
                f.writelines(cleaned)

            # Validate dnsmasq config
            subprocess.run(["dnsmasq", "--test"], check=True)

            # Restart dnsmasq
            subprocess.run(["systemctl", "restart", "dnsmasq"], check=True)

            # Flush dnsmasq cache
            subprocess.run(["killall", "-HUP", "dnsmasq"], check=True)

            return True, f"Updated DNS record {domain} → {ip} via dnsmasq"

        else:
            # BIND fallback (unchanged)
            with open(BIND_ZONE, "a") as f:
                f.write(f"{domain}. IN A {ip}\n")

            subprocess.run(
                ["named-checkzone", ZONE_NAME, BIND_ZONE],
                check=True
            )
            subprocess.run(["systemctl", "reload", "bind9"], check=True)

            return True, "Updated via BIND"

    except Exception as e:
        return False, str(e)
