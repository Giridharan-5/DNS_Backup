import os
import subprocess
import re

DNSMASQ_CONF = "/etc/dnsmasq.d/custom-dns.conf"
BIND_ZONE = "/etc/bind/db.mfg-itis.tcs"
ZONE_NAME = "mfg-itis.tcs"

USE_DNSMASQ = os.path.exists(DNSMASQ_CONF)

def _valid_domain(d): return re.fullmatch(r"[a-zA-Z0-9.-]+", d)
def _valid_ip(i): return re.fullmatch(r"(?:\d{1,3}\.){3}\d{1,3}", i)

def update_dns(domain: str, ip: str):
    if not _valid_domain(domain) or not _valid_ip(ip):
        return False, "Invalid input"

    if USE_DNSMASQ:
        record = f"address=/{domain}/{ip}\n"
        with open(DNSMASQ_CONF, "a") as f:
            f.write(record)

        subprocess.run(["dnsmasq", "--test"], check=True)
        subprocess.run(["systemctl", "restart", "dnsmasq"], check=True)
        return True, "Updated via dnsmasq"

    else:
        with open(BIND_ZONE, "a") as f:
            f.write(f"{domain}. IN A {ip}\n")

        subprocess.run(
            ["named-checkzone", ZONE_NAME, BIND_ZONE],
            check=True
        )
        subprocess.run(["systemctl", "reload", "bind9"], check=True)
        return True, "Updated via BIND"
