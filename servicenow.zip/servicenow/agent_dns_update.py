import subprocess
import re
import os

from config import (
    DNS_SERVER_IP,
    DNS_SERVER_USER,
    DNS_ZONE_FILE,
    DNS_ZONE_NAME,
    SSH_KEY
)

# -----------------------------
# EXPAND SSH KEY PATH
# -----------------------------
SSH_KEY = os.path.expanduser(SSH_KEY)

# -----------------------------
# VALIDATE DOMAIN
# -----------------------------
def _valid_domain(domain: str) -> bool:
    if not domain:
        return False
    return bool(re.fullmatch(
        r"(?!-)[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+",
        domain
    ))

# -----------------------------
# VALIDATE IP (STRICT)
# -----------------------------
def _valid_ip(ip: str) -> bool:
    return bool(re.fullmatch(
        r"(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)"
        r"(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}",
        ip
    ))

# -----------------------------
# UPDATE DNS RECORD
# -----------------------------
def update_dns(domain: str, ip: str):
    try:
        if not _valid_domain(domain):
            return False, "Invalid domain"

        if not _valid_ip(ip):
            return False, "Invalid IP address"

        # Extract hostname for BIND zone
        if domain.endswith(f".{DNS_ZONE_NAME}"):
            record_name = domain.replace(f".{DNS_ZONE_NAME}", "")
        else:
            record_name = domain

        ssh_cmd = f"""
SERIAL=$(date +%Y%m%d%H)
# Remove existing A record for this hostname if present
sudo sed -i '/^{record_name} IN A/d' {DNS_ZONE_FILE} &&
# Update serial
sudo sed -i "s/[0-9]\\{{10\\}}/$SERIAL/" {DNS_ZONE_FILE} &&
# Add new A record
echo "{record_name} IN A {ip}" | sudo tee -a {DNS_ZONE_FILE} >/dev/null &&
# Validate zone
sudo named-checkzone {DNS_ZONE_NAME} {DNS_ZONE_FILE} &&
# Reload BIND
sudo systemctl reload bind9 &&
# Wait a second to allow propagation
sleep 1
"""

        subprocess.run(
            [
                "ssh",
                "-i", SSH_KEY,
                "-o", "BatchMode=yes",
                "-o", "StrictHostKeyChecking=no",
                f"{DNS_SERVER_USER}@{DNS_SERVER_IP}",
                ssh_cmd
            ],
            check=True
        )

        return True, f"DNS record updated for {domain} -> {ip}"

    except subprocess.CalledProcessError as e:
        return False, f"DNS update failed: {e}"


        return True, f"DNS record updated for {domain} -> {ip}"

    except subprocess.CalledProcessError as e:
        return False, f"DNS update failed: {e}"
