import subprocess
import time

DNS_IP = "10.0.0.6"
DNS_PORT = "53"


def postcheck_domain(domain: str):
    try:
        time.sleep(1)

        result = subprocess.run(
            ["dig", f"@{DNS_IP}", "-p", DNS_PORT, domain, "+short"],
            capture_output=True,
            text=True,
            check=False
        )

        if result.stdout.strip():
           return True, f"Resolved IP(s): {', '.join(result.stdout.splitlines())}"

        return False, "Still not resolving"

    except Exception as e:
        return False, f"Postcheck failed: {e}"
