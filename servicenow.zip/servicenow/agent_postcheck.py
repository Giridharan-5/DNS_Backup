import subprocess
import time

DNS_IP = "10.0.0.6"
DNS_PORT = "53"


def postcheck_domain(domain: str):
    try:
        time.sleep(1)

        result = subprocess.run(
            ["dig", f"@{DNS_IP}", domain, "A"],
            capture_output=True,
            text=True,
            check=False
        )

        dig_output = result.stdout.strip()

        formatted_output = (
            "\n\n"
            "----- POSTCHECK OUTPUT -----\n"
            f"{dig_output}\n"
            "--------------------------------\n"
        )

        # Determine success by checking ANSWER section existence
        has_answer = any(
            line and not line.startswith(";")
            for line in dig_output.splitlines()
        )

        if has_answer:
            return True, formatted_output
        else:
            return False, formatted_output

    except Exception as e:
        return False, f"[POSTCHECK ERROR] {e}"
