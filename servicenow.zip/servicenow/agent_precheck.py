import subprocess

DNS_SERVER = "127.0.0.1#1053"  # dnsmasq

def precheck_domain(domain: str):
    try:
        result = subprocess.run(
            ["dig", f"@{DNS_SERVER}", domain, "+short"],
            capture_output=True,
            text=True,
            check=True
        )
        if result.stdout.strip():
            return True, f"Domain exists: {result.stdout.strip()}"
        return False, "Domain does not exist"
    except subprocess.CalledProcessError as e:
        return False, f"Precheck failed: {e}"
