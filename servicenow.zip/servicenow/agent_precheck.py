import subprocess
import time
import re

DNS_IP = "10.0.0.6"
DNS_PORT = "53"


def precheck_domain(domain: str):
    try:
        time.sleep(1)

        result = subprocess.run(
            ["dig", f"@{DNS_IP}", domain, "A"],
            capture_output=True,
            text=True,
            check=False
        )

        dig_output = result.stdout.strip()

        answer_lines = []
        for line in dig_output.splitlines():
            if line.startswith(";"):
                continue
            if domain in line:
                answer_lines.append(line)

        formatted_output = (
            "\n----- PRECHECK OUTPUT -----\n" +
            ("\n".join(answer_lines) if answer_lines else "NO ANSWER FOUND") +
            "\n-------------------------------"
        )

        import re
        resolved_ips = []
        for line in answer_lines:
            match = re.search(r"\b\d{1,3}(?:\.\d{1,3}){3}\b", line)
            if match:
                resolved_ips.append(match.group())

        exists = bool(resolved_ips)

        return exists, resolved_ips, formatted_output

    except Exception as e:
        return False, [], f"[PRECHECK ERROR] {e}"