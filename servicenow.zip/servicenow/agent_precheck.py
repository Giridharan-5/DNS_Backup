import subprocess

DNS_SERVER = "127.0.0.1#1053"  # dnsmasq

def precheck_domain(domain: str):
    try:
        result = subprocess.run(
            ["dig", f"@{DNS_SERVER}", domain, "+short"],
            capture_output=True,
            text=True
        )

        if result.stdout.strip():
            return True, f"Domain exists: {result.stdout.strip()}"

        return False, "Domain does not exist"

    except Exception as e:
        return False, f"Precheck execution error: {e}"

