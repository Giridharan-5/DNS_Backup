import subprocess
import time
DNS_IP = "10.0.0.6"
DNS_PORT = "53"


def precheck_domain(domain: str):
    try:
        time.sleep(1)
        result = subprocess.run(
            ["dig", f"@{DNS_IP}", "-p", DNS_PORT, domain, "+short"],
            capture_output=True,
            text=True,
            check=False
        )

        resolved_ips = [
            ip.strip()
            for ip in result.stdout.splitlines()
            if ip.strip()
        ]

        if resolved_ips:
            return True, resolved_ips   # ✅ ALWAYS list
        else:
            return False, []             # ✅ ALWAYS list

    except Exception as e:
        return False, []
