import requests
from datetime import datetime

# -----------------------------
# Import Config
# -----------------------------
from config import (
    SERVICENOW_USER,
    SERVICENOW_PASS,
    SERVICENOW_INSTANCE,
    CALLER_NAME
)

# -----------------------------
# ServiceNow Config
# -----------------------------
BASE_URL = f"https://{SERVICENOW_INSTANCE}.service-now.com/api/now/table"
AUTH = (SERVICENOW_USER, SERVICENOW_PASS)
HEADERS = {"Content-Type": "application/json"}

# -----------------------------
# Get sys_id for caller
# -----------------------------
def get_sys_id_for_caller():
    url = f"{BASE_URL}/sys_user"
    params = {
        "sysparm_query": f"name={CALLER_NAME}",
        "sysparm_fields": "sys_id,name"
    }

    try:
        r = requests.get(url, auth=AUTH, headers=HEADERS, params=params)
        r.raise_for_status()
        users = r.json().get("result", [])
        if not users:
            print(f"[ERROR] No sys_id found for caller {CALLER_NAME}")
            return None
        sys_id = users[0]["sys_id"]
        print(f"[INFO] Caller {CALLER_NAME} sys_id: {sys_id}")
        return sys_id
    except requests.RequestException as e:
        print(f"[ERROR] Failed to fetch caller sys_id: {str(e)}")
        return None

# -----------------------------
# Fetch tickets for caller
# -----------------------------
def fetch_tickets():
    caller_sys_id = get_sys_id_for_caller()
    if not caller_sys_id:
        return []

    url = f"{BASE_URL}/incident"
    params = {
        "sysparm_query": f"caller_id={caller_sys_id}^active=true",
        "sysparm_fields": "sys_id,number,short_description,description"
    }

    try:
        r = requests.get(url, auth=AUTH, headers=HEADERS, params=params)
        r.raise_for_status()
        tickets = r.json().get("result", [])
        print(f"[INFO] Fetched {len(tickets)} tickets for {CALLER_NAME}")
        return tickets
    except requests.RequestException as e:
        print(f"[ERROR] Failed to fetch tickets: {str(e)}")
        return []

# -----------------------------
# Resolve ticket
# -----------------------------
def resolve_ticket(ticket_sys_id, summary):
    url = f"{BASE_URL}/incident/{ticket_sys_id}"

    # Correct fields for your instance
    data = {
        "incident_state": "6",  # Resolved
        "close_code": "Solution provided",  # The resolution code (adjust as per need)
        "close_notes": summary,  # Close Notes (resolution)
        "work_notes": summary,  # Work Notes (additional info)
        "knowledge": True,  # Knowledge flag (True to indicate a knowledge article)
        "resolved_by": SERVICENOW_USER,  # Assuming you're resolving the ticket
        "resolved_at": datetime.now().isoformat(),  # Time of resolution
        "resolution_code": "solution_provided"  # This is your custom field for resolution
    }

    try:
        # Send the PATCH request to resolve the ticket
        r = requests.patch(url, auth=AUTH, headers=HEADERS, json=data)
        r.raise_for_status()  # Ensure no errors are raised
        print(f"[RESOLVE] Ticket {ticket_sys_id} successfully resolved.")
        return True
    except requests.RequestException as e:
        print(f"[RESOLVE] Failed to resolve ticket {ticket_sys_id}: {str(e)}")
        return False
