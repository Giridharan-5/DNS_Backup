import re

# -----------------------------
# KEYWORDS
# -----------------------------
 
DNS_ADD_KEYWORDS = [
    # generic
    "add dns", "add record", "add a domain", "create dns", "create record",
    "new dns", "new record", "register domain", "dns entry",

    # A record specific
    "a record", "add a record", "create a record",

    # common ITSM wording
    "map domain", "map ip", "point domain", "point to ip",
    "dns mapping", "domain mapping",

    # informal / real-world
    "need dns", "dns required", "please add dns", "request dns",
    "configure dns", "setup dns"
]

DNS_UPDATE_KEYWORDS = [
    # generic
    "update dns", "modify dns", "change dns", "edit dns",
    "update record", "modify record",

    # IP related
    "change ip", "update ip", "ip change", "replace ip",
    "old ip", "new ip",

    # real-world phrasing
    "dns update", "update mapping", "change mapping",
    "dns correction", "fix dns", "wrong ip",
    "point to new ip"
]

DNS_DELETE_KEYWORDS = [
    # generic
    "delete dns", "remove a dns", "delete a record", "remove a record",
    "delete a domain", "remove a domain",

    # decommission wording
    "decommission dns", "decommission domain",
    "retire dns", "retire domain",

    # cleanup wording
    "cleanup dns", "dns cleanup",
    "obsolete dns", "unused dns",

    # informal
    "no longer needed", "not required anymore",
    "please remove dns", "remove mapping"
]

# -----------------------------
# PARSERS
# -----------------------------

def extract_domain_ip(text: str):
    ips = re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", text)

    raw_domains = re.findall(
    r"\b[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+\b",
    text )

    domains = []
    for d in raw_domains:
        d = d.rstrip(".")  # remove trailing dot
        if d.lower() in {"i", "we", "want", "add", "domain"}:
            continue

        if d.endswith("mfg-itis.tcs"):
            domains.append(d)
        elif "." in d:
            domains.append(d)
        else:
            domains.append(f"{d}.mfg-itis.tcs")


    return {
        "domains": domains,
        "ips": ips
    }




# -----------------------------
# CLASSIFIER
# -----------------------------

def classify_ticket(short_desc: str, desc: str):
    text = f"{short_desc} {desc}".lower()

    if any(k in text for k in DNS_DELETE_KEYWORDS):
        return "DNS_DELETE"

    if any(k in text for k in DNS_UPDATE_KEYWORDS):
        return "DNS_UPDATE"

    if any(k in text for k in DNS_ADD_KEYWORDS):
        return "DNS_ADD"

    return "NON_DNS"

# -----------------------------
# SINGLE ENTRY FUNCTION
# -----------------------------

import re

def analyze_ticket(short_description: str, description: str):
    """
    Analyze ticket text and extract:
    - classification: DNS_ADD, DNS_UPDATE, DNS_DELETE, NON_DNS
    - domains: [old_domain, new_domain] (if applicable)
    - ips: [old_ip, new_ip] (if applicable)
    """
    text = f"{short_description}\n{description}".lower()

    # -----------------------------
    # Detect operation type
    # -----------------------------
    if "delete" in text:
        classification = "DNS_DELETE"
    elif "update" in text or "modify" in text or "change" in text:
        classification = "DNS_UPDATE"
    elif "add" in text or "create" in text or "new domain" in text:
        classification = "DNS_ADD"
    else:
        classification = "NON_DNS"

    # -----------------------------
    # Extract domain names
    # -----------------------------
    domain_pattern = r"\b([a-z0-9.-]+\.[a-z]{2,})\b"
    found_domains = re.findall(domain_pattern, description.lower())
    domains = []
    for d in found_domains:
        if d not in domains:
            domains.append(d)

    # -----------------------------
    # Extract IP addresses
    # -----------------------------
    ip_pattern = r"\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b"
    found_ips = re.findall(ip_pattern, description)
    ips = []
    for ip in found_ips:
        if ip not in ips:
            ips.append(ip)

    # -----------------------------
    # Normalize for graph
    # -----------------------------
    old_domain = domains[0] if domains else None
    new_domain = domains[1] if len(domains) >= 2 else old_domain

    old_ip = None
    new_ip = None

    if classification == "DNS_UPDATE":
        # For updates: first IP is old, second is new
        old_ip = ips[0] if ips else None
        new_ip = ips[1] if len(ips) >= 2 else None
    else:
        # For ADD/DELETE: first IP is primary, second optional
        old_ip = ips[0] if ips else None
        new_ip = ips[1] if len(ips) >= 2 else old_ip

    return {
        "classification": classification,
        "domains": [old_domain, new_domain] if old_domain else [],
        "ips": [old_ip, new_ip] if old_ip else []
    }
