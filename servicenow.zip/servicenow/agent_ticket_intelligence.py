import re
import os
import json
import requests
 

DEBUG = False

# -----------------------------
# PARSERS
# -----------------------------

def extract_domain_ip(text: str):
    result = _llm_analyze(text)
    return {
        "domains": result.get("domains", []),
        "ips": result.get("ips", [])
    }

# -----------------------------
# CLASSIFIER
# -----------------------------

def classify_ticket(short_desc: str, desc: str):
    result = _llm_analyze(f"{short_desc}\n{desc}")
    return result.get("classification", "NON_DNS")

# -----------------------------
# SINGLE ENTRY FUNCTION
# -----------------------------

def analyze_ticket(short_description: str, description: str):
    result = _llm_analyze(f"{short_description}\n{description}")

    classification = result.get("classification", "NON_DNS")
    domains = result.get("domains", [])
    ips = result.get("ips", [])

    old_ip = None
    new_ip = None

    # 🔥 DNS UPDATE SMART HANDLING
    if classification == "DNS_UPDATE" and len(ips) >= 2:
        old_ip = ips[0]
        new_ip = ips[1]

    return {
        "classification": classification,
        "domains": domains,
        "ips": ips,              # keep existing for backward compatibility
        "old_ip": old_ip,        # NEW
        "new_ip": new_ip,        # NEW
        "warning": result.get("warning")
    }

# -------------------------------------------------
# INTERNAL LLM ANALYSIS (FIXED & RELIABLE)
# -------------------------------------------------

def _llm_analyze(text: str):

    # ===== SAFETY GUARD (KEEP) =====
    danger_patterns = [
        r"delete\s+all\s+dns",
        r"wipe\s+entire\s+dns",
        r"clear\s+entire\s+dns",
        r"drop\s+dns\s+database"
    ]

    for pattern in danger_patterns:
        if re.search(pattern, text.lower()):
            return {
                "classification": "NON_DNS",
                "domains": [],
                "ips": [],
                "warning": "Potentially destructive DNS request detected"
            }
    # ==============================

    api_key = os.getenv("GROQ_API_KEY")
    #print("[DEBUG] GROQ KEY FOUND:", bool(api_key))
    if not api_key:
        return {
            "classification": "NON_DNS",
            "domains": [],
            "ips": [],
            "warning": None
        }

    prompt = f"""
You are an enterprise DNS automation engine.

Your job is to AUTOMATICALLY resolve DNS tickets.

STEP 1 — INTENT (MANDATORY):
Decide ONE intent based on meaning, not grammar.

INTENTS:
- DNS_ADD → create / add / new / onboarding / map / point / A record
- DNS_UPDATE → update / modify / change / incorrect IP / repoint
- DNS_DELETE → delete / remove / decommission
- NON_DNS → not DNS related

IMPORTANT RULES:
- If domain and IP exists and user wants to remove old IP and add different IP → DNS_UPDATE
- If domain does not exist and user wants creation → DNS_ADD
- If user says delete/remove → DNS_DELETE
- Only return: DNS_ADD, DNS_UPDATE, DNS_DELETE, NON_DNS

STEP 2 — EXTRACTION:
- Extract ALL domains
- Extract ALL IPv4 addresses

RETURN STRICT JSON ONLY.

JSON FORMAT:
{{
  "classification": "DNS_ADD | DNS_UPDATE | DNS_DELETE | NON_DNS",
  "domains": [],
  "ips": [],
  "warning": null
}}

Ticket:
{text}
"""

    try:
        response = requests.post(
            "https://api.groq.com/openai/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": "llama-3.1-8b-instant",
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0,
            },
            timeout=20,
        )
    except Exception:
        return {
            "classification": "NON_DNS",
            "domains": [],
            "ips": [],
            "warning": None
        }

    try:
        data = response.json()
        content = data["choices"][0]["message"]["content"].strip()
    except Exception:
        return {
            "classification": "NON_DNS",
            "domains": [],
            "ips": [],
            "warning": None
        }

    parsed_result = None

    try:
        parsed_result = json.loads(content)
    except json.JSONDecodeError:
        pass

    if not parsed_result:
        match = re.search(r"\{.*\}", content, re.DOTALL)
        if match:
            try:
                parsed_result = json.loads(match.group())
            except json.JSONDecodeError:
                parsed_result = None

    if not parsed_result:
        return {
            "classification": "NON_DNS",
            "domains": [],
            "ips": [],
            "warning": None
        }

    # -----------------------------
    # 🔒 DOMAIN SANITIZATION (FIX)
    # -----------------------------

    def _is_valid_domain(d):
        return "." in d and d.lower() not in [
            "all", "everything", "entire", "whole"
        ]

    clean_domains = []
    for d in parsed_result.get("domains", []):
        if _is_valid_domain(d):
            clean_domains.append(d)

    # 🚨 Block delete without explicit domain
    if parsed_result.get("classification") == "DNS_DELETE" and not clean_domains:
        return {
            "classification": "NON_DNS",
            "domains": [],
            "ips": [],
            "warning": "Delete request without explicit domain blocked"
        }

    parsed_result["domains"] = clean_domains

    # ----------------------------------
# NORMALIZE CLASSIFICATION (SAFE)
# ----------------------------------

    valid_classes = ["DNS_ADD", "DNS_UPDATE", "DNS_DELETE", "NON_DNS"]

    classification = parsed_result.get("classification", "NON_DNS")

    if classification not in valid_classes:
        classification = "NON_DNS"
        parsed_result["classification"] = classification
    return parsed_result

# -----------------------------
# BACKWARD-COMPAT SAFE HELPER
# -----------------------------

def _collect_ips(result: dict):
    return result.get("ips", [])