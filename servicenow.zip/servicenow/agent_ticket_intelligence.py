import re

# -----------------------------
# KEYWORDS
# -----------------------------

DNS_ADD_KEYWORDS = [
    "add dns", "add record", "add domain", "create dns", "a record"
]

DNS_UPDATE_KEYWORDS = [
    "update dns", "change ip", "modify dns", "update record"
]

DNS_DELETE_KEYWORDS = [
    "delete dns", "remove dns", "delete record", "remove domain"
]


# -----------------------------
# PARSERS
# -----------------------------

def extract_domain_ip(text: str):
    ip_match = re.search(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", text)
    domain_match = re.search(r"\b[a-zA-Z0-9-]+\.[a-zA-Z0-9.-]+\b", text)

    domain = domain_match.group() if domain_match else None
    ip = ip_match.group() if ip_match else None

    return domain, ip


# -----------------------------
# CLASSIFIER
# -----------------------------

def classify_ticket(short_desc: str, desc: str):
    text = f"{short_desc} {desc}".lower()

    if any(k in text for k in DNS_DELETE_KEYWORDS):
        return "DNS_DELETE"

    if any(k in text for k in DNS_UPDATE_KEYWORDS):
        return "DNS_UPDATE"

    if any(k in text for k in DNS_ADD_KEYWORDS):
        return "DNS_ADD"

    return "NON_DNS"


# -----------------------------
# SINGLE ENTRY FUNCTION
# -----------------------------

def analyze_ticket(short_desc: str, desc: str):
    classification = classify_ticket(short_desc, desc)
    domain, ip = extract_domain_ip(short_desc + " " + desc)

    return {
        "classification": classification,
        "domain": domain,
        "ip": ip
    }
