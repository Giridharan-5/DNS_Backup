import re

# -----------------------------
# KEYWORDS
# -----------------------------
 
DNS_ADD_KEYWORDS = [
    # generic
    "add dns", "add record", "add domain", "create dns", "create record",
    "new dns", "new record", "register domain", "dns entry",

    # A record specific
    "a record", "add a record", "create a record",

    # common ITSM wording
    "map domain", "map ip", "point domain", "point to ip",
    "dns mapping", "domain mapping",

    # informal / real-world
    "need dns", "dns required", "please add dns", "request dns",
    "configure dns", "setup dns"
]

DNS_UPDATE_KEYWORDS = [
    # generic
    "update dns", "modify dns", "change dns", "edit dns",
    "update record", "modify record",

    # IP related
    "change ip", "update ip", "ip change", "replace ip",
    "old ip", "new ip",

    # real-world phrasing
    "dns update", "update mapping", "change mapping",
    "dns correction", "fix dns", "wrong ip",
    "point to new ip"
]

DNS_DELETE_KEYWORDS = [
    # generic
    "delete dns", "remove dns", "delete record", "remove record",
    "delete domain", "remove domain",

    # decommission wording
    "decommission dns", "decommission domain",
    "retire dns", "retire domain",

    # cleanup wording
    "cleanup dns", "dns cleanup",
    "obsolete dns", "unused dns",

    # informal
    "no longer needed", "not required anymore",
    "please remove dns", "remove mapping"
]

# -----------------------------
# PARSERS
# -----------------------------

def extract_domain_ip(text: str):
    ip_match = re.search(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", text)
    domain_match = re.search(r"\b[a-zA-Z0-9-]+\.[a-zA-Z0-9.-]+\b", text)

    domain = domain_match.group() if domain_match else None
    ip = ip_match.group() if ip_match else None

    return domain, ip

# -----------------------------
# CLASSIFIER
# -----------------------------

def classify_ticket(short_desc: str, desc: str):
    text = f"{short_desc} {desc}".lower()

    if any(k in text for k in DNS_DELETE_KEYWORDS):
        return "DNS_DELETE"

    if any(k in text for k in DNS_UPDATE_KEYWORDS):
        return "DNS_UPDATE"

    if any(k in text for k in DNS_ADD_KEYWORDS):
        return "DNS_ADD"

    return "NON_DNS"

# -----------------------------
# SINGLE ENTRY FUNCTION
# -----------------------------

def analyze_ticket(short_desc: str, desc: str):
    classification = classify_ticket(short_desc, desc)
    domain, ip = extract_domain_ip(short_desc + " " + desc)

    return {
        "classification": classification,
        "domain": domain,
        "ip": ip
    }
