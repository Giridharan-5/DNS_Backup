# config.py
#import os
# -----------------------------
# ServiceNow Configuration
# -----------------------------

SERVICENOW_INSTANCE = "dev270315"
SERVICENOW_USER = "admin"
SERVICENOW_PASS = "Giri@1848"
 
CALLER_NAME = "Giridharan"
TABLE_NAME = "incident"
 
 
DNS_SERVER_IP = "10.0.0.6"
DNS_SERVER_USER = "linuxvm1"
DNS_ZONE_FILE = "/etc/bind/db.mfg-itis.tcs"
DNS_ZONE_NAME = "mfg-itis.tcs"

SSH_KEY_PATH = "/home/linuxadmin/.ssh/id_dns_automation"
SSH_KEY = "~/.ssh/id_dns_automation"



GROQ_API_KEY = "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"
