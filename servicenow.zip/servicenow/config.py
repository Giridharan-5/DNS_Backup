# config.py

# -----------------------------
# ServiceNow Configuration
# -----------------------------

SERVICENOW_INSTANCE = "dev270315"
SERVICENOW_USER = "admin"
SERVICENOW_PASS = "Cj$yD6c-rC2P"

CALLER_NAME = "Giridharan"
TABLE_NAME = "incident"
 
