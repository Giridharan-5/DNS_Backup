# config.py
#import os
# -----------------------------
# ServiceNow Configuration
# -----------------------------

SERVICENOW_INSTANCE = "dev270315"
SERVICENOW_USER = "admin"
#SERVICENOW_PASS = os.getenv("SERVICENOW_PASS")
SERVICENOW_PASS = "Cj$yD6c-rC2P"

CALLER_NAME = "Giridharan"
TABLE_NAME = "incident"
 
 
DNS_SERVER_IP = "10.0.0.6"
DNS_SERVER_USER = "linuxvm1"
DNS_ZONE_FILE = "/etc/bind/db.mfg-itis.tcs"
DNS_ZONE_NAME = "mfg-itis.tcs"

SSH_KEY_PATH = "/home/linuxadmin/.ssh/id_dns_automation"
SSH_KEY = "~/.ssh/id_dns_automation"



