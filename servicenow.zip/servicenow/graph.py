from typing import TypedDict, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed
from langgraph.graph import StateGraph, END

from agent_ticket_intelligence import analyze_ticket
from agent_precheck import precheck_domain
from agent_postcheck import postcheck_domain
from agent_dns_add import add_dns
from agent_dns_update import update_dns
from agent_dns_delete import delete_dns
from agent_servicenow import fetch_tickets, resolve_ticket

# -----------------------------
# STATE DEFINITION
# -----------------------------
class TicketState(TypedDict):
    ticket: dict
    classification: str
    domain: Optional[str]
    ip: Optional[str]
    steps: list
    success: bool

# -----------------------------
# GRAPH NODES
# -----------------------------
def analyze_node(state: TicketState):
    t = state["ticket"]
    result = analyze_ticket(t.get("short_description", ""), t.get("description", ""))

    state["classification"] = result["classification"]
    state["domain"] = result["domain"]
    state["ip"] = result["ip"]

    state["steps"].append(f"[ANALYZE] Classification: {state['classification']}")
    state["steps"].append(f"[ANALYZE] Domain: {state['domain']}")
    state["steps"].append(f"[ANALYZE] IP: {state['ip']}")

    return state

def dns_add_node(state: TicketState):
    state["steps"].append(f"[DNS_ADD] Starting precheck for {state['domain']}")
    exists, msg = precheck_domain(state["domain"])
    state["steps"].append(f"[DNS_ADD] Precheck: {msg}")

    if exists:
        state["steps"].append(f"[DNS_ADD] Record already exists. Skipping ADD.")
        state["success"] = True
        return state

    ok, msg = add_dns(state["domain"], state["ip"])
    state["steps"].append(f"[DNS_ADD] {msg}")
    state["success"] = ok
    return state

def dns_update_node(state: TicketState):
    state["steps"].append(f"[DNS_UPDATE] Updating DNS record for {state['domain']}")
    ok, msg = update_dns(state["domain"], state["ip"])
    state["steps"].append(f"[DNS_UPDATE] {msg}")
    state["success"] = ok
    return state

def dns_delete_node(state: TicketState):
    state["steps"].append(f"[DNS_DELETE] Deleting DNS record for {state['domain']}")
    ok, msg = delete_dns(state["domain"])
    state["steps"].append(f"[DNS_DELETE] {msg}")
    state["success"] = ok
    return state

def postcheck_node(state: TicketState):
    state["steps"].append(f"[POSTCHECK] Verifying DNS resolution for {state['domain']}")
    ok, msg = postcheck_domain(state["domain"])
    state["steps"].append(f"[POSTCHECK] {msg}")
    state["success"] = ok

    if not ok:
        state["steps"].append("[POSTCHECK] DNS verification failed. Ticket will not be resolved.")
    
    return state


def resolve_node(state: TicketState):

    classification = state["classification"]
    domain = state["domain"]
    ip = state["ip"]

    if classification == "DNS_ADD":
        summary = (
            "DNS record was successfully added to the DNS server.\n\n"
            f"Domain Name : {domain}\n"
            f"IP Address : {ip}\n\n"
            "The DNS configuration was updated and verified as per the request."
        )

    elif classification == "DNS_UPDATE":
        summary = (
            "DNS record was successfully updated on the DNS server.\n\n"
            f"Domain Name : {domain}\n"
            f"Updated IP Address : {ip}\n\n"
            "The DNS change was completed and verified."
        )

    elif classification == "DNS_DELETE":
        summary = (
            "DNS record was successfully removed from the DNS server.\n\n"
            f"Domain Name : {domain}\n\n"
            "The DNS entry has been decommissioned as requested."
        )

    else:  # NON_DNS
        summary = (
            "The ticket was reviewed and determined to be non-DNS related.\n\n"
            "No DNS changes were required for this request.\n"
            "The ticket has been closed after validation."
        )

    if resolve_ticket(state["ticket"]["sys_id"], summary):
        state["steps"].append(f"[RESOLVE] Ticket {state['ticket']['number']} resolved successfully.")
    else:
        state["steps"].append(f"[RESOLVE] Ticket {state['ticket']['number']} FAILED to resolve.")

    return state


# -----------------------------
# ROUTER
# -----------------------------
def route_by_type(state: TicketState):
    return state["classification"]

# -----------------------------
# GRAPH BUILD
# -----------------------------
graph = StateGraph(TicketState)

graph.set_entry_point("analyze")

graph.add_node("analyze", analyze_node)
graph.add_node("dns_add", dns_add_node)
graph.add_node("dns_update", dns_update_node)
graph.add_node("dns_delete", dns_delete_node)
graph.add_node("postcheck", postcheck_node)
graph.add_node("resolve", resolve_node)

graph.add_conditional_edges(
    "analyze",
    route_by_type,
    {
        "DNS_ADD": "dns_add",
        "DNS_UPDATE": "dns_update",
        "DNS_DELETE": "dns_delete",
        "NON_DNS": "resolve"
    }
)

graph.add_edge("dns_add", "postcheck")
graph.add_edge("dns_update", "postcheck")
graph.add_edge("dns_delete", "postcheck")
def postcheck_router(state: TicketState):
    return "SUCCESS" if state["success"] else "FAIL"

graph.add_conditional_edges(
    "postcheck",
    postcheck_router,
    {
        "SUCCESS": "resolve",
        "FAIL": END
    }
)

graph.add_edge("resolve", END)

app = graph.compile()

# -----------------------------
# TICKET PROCESSOR
# -----------------------------
def process_ticket(ticket):
    state = {
        "ticket": ticket,
        "classification": "",
        "domain": None,
        "ip": None,
        "steps": [f"[START] Ticket {ticket['number']} processing started"],
        "success": False
    }
    app.invoke(state)
    output = "\n".join(state["steps"])
    return ticket["number"], output

# -----------------------------
# RUNNER WITH CONCURRENCY
# -----------------------------
def run():
    tickets = fetch_tickets()
    if not tickets:
        print("[INFO] No tickets found for caller Giridharan.")
        return

    print(f"[INFO] Fetched {len(tickets)} tickets for Giridharan.\n")

    MAX_WORKERS = 5
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_to_ticket = {executor.submit(process_ticket, t): t for t in tickets}

        for future in as_completed(future_to_ticket):
            ticket_number, output = future.result()
            print(f"\n--- Ticket {ticket_number} Output ---")
            print(output)
            print(f"--- End of Ticket {ticket_number} ---\n")

if __name__ == "__main__":
    run()
