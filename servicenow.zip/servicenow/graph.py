from typing import TypedDict, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed
from langgraph.graph import StateGraph, END

from agent_ticket_intelligence import analyze_ticket
from agent_precheck import precheck_domain
from agent_postcheck import postcheck_domain
from agent_dns_add import add_dns
from agent_dns_update import update_dns
from agent_dns_delete import delete_dns
from agent_servicenow import fetch_tickets, resolve_ticket

# -----------------------------
# STATE DEFINITION
# -----------------------------
class TicketState(TypedDict):
    ticket: dict
    classification: str
    domain: Optional[str]
    ip: Optional[str]
    domains: list          # ✅ ADD THIS
    steps: list
    success: bool


# -----------------------------
# GRAPH NODES
# -----------------------------
def check_already_resolved_node(state: TicketState):
    if state["ticket"].get("incident_state") == "6":
        state["steps"].append(
            "[INFO] Ticket already resolved. No action required."
        )
        state["success"] = True
        return state
    return state


def analyze_node(state: TicketState):
    t = state["ticket"]
    result = analyze_ticket(
        t.get("short_description", ""),
        t.get("description", "")
    )

    state["classification"] = result["classification"]

    domains = result.get("domains", [])
    ips = result.get("ips", [])

    # Normalize into state
    state["domains"] = [d.strip() for d in domains]  # Strip whitespace
    state["domain"] = state["domains"][0] if state["domains"] else None

    state["ips"] = [ip.strip() for ip in ips]  # Strip whitespace
    state["ip"] = state["ips"][-1] if state["ips"] else None  # last IP = target IP

    state["steps"].append(f"[ANALYZE] Classification: {state['classification']}")
    state["steps"].append(f"[ANALYZE] Domain: {state['domain']}")
    state["steps"].append(f"[ANALYZE] IP: {state['ip']}")

    return state



def dns_add_node(state: TicketState):

    if not state["domain"] or not state["ip"]:
        state["steps"].append(
            "[DNS_ADD] Missing domain or IP. Ticket does not contain valid DNS data."
        )
        state["success"] = False
        return state

    state["steps"].append(f"[PRECHECK] Starting precheck for {state['domain']}")
    exists, ips = precheck_domain(state["domain"])  # ✅ Only one call now

    if exists:
        state["steps"].append(f"[PRECHECK] Domain exists with IP(s): {', '.join(ips)}")
        state["steps"].append(f"[PRECHECK] Domain already exists with IP: {ips[0] if ips else 'None'}. ADD not required.")
        state["success"] = True
        return state
    else:
        state["steps"].append("[PRECHECK] Domain not present in DNS")

    ok, msg = add_dns(state["domain"], state["ip"])
    state["steps"].append(f"[DNS_ADD] {msg}")
    state["success"] = ok
    return state



def dns_update_node(state: TicketState):
    new_ip = state["ip"]

    state["steps"].append(f"[PRE-CHECK] Precheck for existing record {state['domain']}")
    exists, current_ips = precheck_domain(state["domain"])
    state["steps"].append(f"[PRE-CHECK] Existing IP(s): {current_ips}")

    # Domain must exist
    if not exists:
        state["steps"].append("[PRE-CHECK] Domain not found. Cannot update DNS.")
        state["success"] = False
        return state

    # Idempotency check — IP already present
    if new_ip in current_ips:
        state["steps"].append(f"[DNS_UPDATE] IP {new_ip} already exists. No update required.")
        state["success"] = True
        return state

    # Pick old IP to replace (if multiple, pick first)
    old_ip = current_ips[0] if current_ips else None
    state["steps"].append(f"[DNS_UPDATE] Updating IP {old_ip} → {new_ip}")

    # Perform IP update
    ok, msg = update_dns(state["domain"], new_ip)
    state["steps"].append(f"[DNS_UPDATE] {msg}")
    state["ip"] = new_ip
    state["success"] = ok
    return state



def dns_delete_node(state: TicketState):
    state["steps"].append(f"[DNS_DELETE] Precheck for {state['domain']}")
    exists, ips = precheck_domain(state["domain"])  # ✅ Only one call now

    if exists:
        state["steps"].append(f"[DNS_DELETE] Domain exists with IP(s): {', '.join(ips)}")
    else:
        state["steps"].append("[DNS_DELETE] Domain not present. Nothing to delete.")
        state["steps"].append("[DNS_DELETE] Record not present. Desired state already achieved.")
        state["success"] = True
        return state

    ok, msg = delete_dns(state["domain"])
    state["steps"].append(f"[DNS_DELETE] {msg}")

    # Post-delete verification
    exists, ips = precheck_domain(state["domain"])
    if exists:
        state["steps"].append("[DNS_DELETE] Record still exists after delete.")
        state["success"] = False
    else:
        state["steps"].append("[DNS_DELETE] Record deletion verified.")
        state["success"] = True

    return state



def postcheck_node(state: TicketState):
    state["steps"].append(f"[POSTCHECK] Verifying DNS resolution for {state['domain']}")
    ok, msg = postcheck_domain(state["domain"])
    state["steps"].append(f"[POSTCHECK] {msg}")
    state["success"] = ok

    if not ok:
        state["success"] = False
    
    return state


def resolve_node(state: TicketState):
    
    if not state["success"]:
        state["steps"].append(
            "[RESOLVE] Ticket not resolved because DNS operation verification failed."
        )
        return state

    classification = state["classification"]
    domain = state["domain"]
    ip = state["ip"]

    if classification == "DNS_ADD":
        summary = (
            "DNS record was successfully added to the DNS server.\n\n"
            f"Domain Name : {domain}\n"
            f"IP Address : {ip}\n\n"
            "The DNS configuration was updated and verified as per the request."
        )

    elif classification == "DNS_UPDATE":
        summary = (
            "DNS record was successfully updated on the DNS server.\n\n"
            f"Domain Name : {domain}\n"
            f"Updated IP Address : {ip}\n\n"
            "The DNS change was completed and verified."
        )

    elif classification == "DNS_DELETE":
        summary = (
            "DNS record was successfully removed from the DNS server.\n\n"
            f"Domain Name : {domain}\n\n"
            "The DNS entry has been decommissioned as requested."
        )

    else:  # NON_DNS
        summary = (
            "The ticket was reviewed and determined to be non-DNS related.\n\n"
            "No DNS changes were required for this request.\n"
            "The ticket has been closed after validation."
        )

    if resolve_ticket(state["ticket"]["sys_id"], summary):
        state["steps"].append(f"[RESOLVE] Ticket {state['ticket']['number']} resolved successfully.")
    else:
        state["steps"].append(f"[RESOLVE] Ticket {state['ticket']['number']} FAILED to resolve.")

    return state


# -----------------------------
# ROUTER
# -----------------------------
def route_by_type(state: TicketState):
    return state["classification"]

# -----------------------------
# GRAPH BUILD
# -----------------------------
graph = StateGraph(TicketState)

graph.set_entry_point("analyze")

graph.add_node("analyze", analyze_node)
graph.add_node("dns_add", dns_add_node)
graph.add_node("dns_update", dns_update_node)
graph.add_node("dns_delete", dns_delete_node)
graph.add_node("postcheck", postcheck_node)
graph.add_node("resolve", resolve_node)

graph.add_conditional_edges(
    "analyze",
    route_by_type,
    {
        "DNS_ADD": "dns_add",
        "DNS_UPDATE": "dns_update",
        "DNS_DELETE": "dns_delete",
        "NON_DNS": "resolve"
    }
)

graph.add_edge("dns_add", "postcheck")
graph.add_edge("dns_update", "postcheck")
graph.add_edge("dns_delete", "resolve")
def postcheck_router(state: TicketState):
    return "SUCCESS" if state["success"] else "FAIL"

graph.add_conditional_edges(
    "postcheck",
    postcheck_router,
    {
        "SUCCESS": "resolve",
        "FAIL": END
    }
)

graph.add_edge("resolve", END)

app = graph.compile()

# -----------------------------
# TICKET PROCESSOR
# -----------------------------
def process_ticket(ticket):
    state = {
        "ticket": ticket,
        "classification": "",
        "domain": None,
        "ip": None,
        "steps": [f"[START] Ticket {ticket['number']} processing started"],
        "success": False
    }

    final_state = app.invoke(state)   # ✅ IMPORTANT

    output = "\n".join(final_state["steps"])
    return ticket["number"], output


# -----------------------------
# RUNNER WITH CONCURRENCY
# -----------------------------
def run():
    tickets = fetch_tickets()
    if not tickets:
        print("[INFO] No tickets found for caller Giridharan.")
        return

    print(f"[INFO] Fetched {len(tickets)} tickets for Giridharan.\n")

    MAX_WORKERS = 5
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_to_ticket = {executor.submit(process_ticket, t): t for t in tickets}

        for future in as_completed(future_to_ticket):
            ticket_number, output = future.result()
            print(f"\n--- Ticket {ticket_number} Output ---")
            print(output)
            print(f"--- End of Ticket {ticket_number} ---\n")

if __name__ == "__main__":
    run()
