from genericpath import exists
from typing import TypedDict, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed
from unittest import result
from langgraph.graph import StateGraph, END
import re
import ipaddress

from agent_ticket_intelligence import analyze_ticket
from agent_precheck import precheck_domain
from agent_postcheck import postcheck_domain
from agent_dns_add import add_dns
from agent_dns_update import update_dns
from agent_dns_delete import delete_dns
from agent_servicenow import fetch_tickets, resolve_ticket

# -----------------------------
# STATE DEFINITION
# -----------------------------
class TicketState(TypedDict):
    ticket: dict
    classification: str
    domain: Optional[str]
    ip: Optional[str]
    domains: list
    ips: list
    old_ip: Optional[str]      
    new_ip: Optional[str]       
    steps: list
    success: bool


SECTION_PRECHECK  = "\n\n" + "=" * 20 + " PRECHECK " + "=" * 20
SECTION_ACTION    = "\n\n" + "=" * 20 + " DNS ACTION " + "=" * 18
SECTION_POSTCHECK = "\n\n" + "=" * 20 + " POSTCHECK " + "=" * 19
SECTION_RESOLVE   = "\n\n" + "=" * 20 + " RESOLUTION " + "=" * 17

# -----------------------------
# GRAPH NODES
# -----------------------------
def check_already_resolved_node(state: TicketState):
    if state["ticket"].get("incident_state") == "6":
        state["steps"].append(
            "[INFO] Ticket already resolved. No action required."
        )
        state["success"] = True
        return state
    return state


import re  # add at top of file if not already imported

def analyze_node(state: TicketState):
    t = state["ticket"]

    result = analyze_ticket(
        t.get("short_description", ""),
        t.get("description", "")
    )

    # ================= SAFETY WARNING (ISSUE 3 FIX) =================
    if result.get("warning"):
        state["steps"].append(
            f"[WARNING] {result['warning']}. Manual review required."
        )
        state["classification"] = "NON_DNS"
        state["success"] = False
        return state
    # ===============================================================

    raw_classification = result.get("classification", "")
    state["classification"] = raw_classification.strip().upper() or "NON_DNS"

    # ---------------- FIX 5: Ensure domain/IP ----------------
    domains = result.get("domains") or []
    ips = result.get("ips") or []

    # fallback: extract domain/IP from ticket text if result is empty
    ticket_text = f"{t.get('short_description','')} {t.get('description','')}"
    
    if not domains:
        found_domains = re.findall(r"\b[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b", ticket_text)
        cleaned_domains = []
        for d in found_domains:
            if not d.startswith(".") and not d.endswith("."):
                cleaned_domains.append(d.lower())
        domains = cleaned_domains

    if not ips:
        found_ips = re.findall(r"\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b", ticket_text)
        valid_ips = []
        for ip in found_ips:
            try:
                ipaddress.ip_address(ip)
                valid_ips.append(ip)
            except ValueError:
                continue
        ips = valid_ips

    # clean whitespace
    state["domains"] = list(set(d.strip() for d in domains if d and d.strip()))
    # Preserve original order (DO NOT use set)
    clean_ips = []
    for ip in ips:
        ip = ip.strip()
        if ip and ip not in clean_ips:
            clean_ips.append(ip)

    state["ips"] = clean_ips

    state["domain"] = state["domains"][0] if state["domains"] else None

# 🔥 DNS UPDATE LOGIC
    state["old_ip"] = None
    state["new_ip"] = None
    
    if state["classification"] == "DNS_UPDATE" and len(clean_ips) >= 2:
        state["old_ip"] = clean_ips[0]
        state["new_ip"] = clean_ips[1]
        state["ip"] = state["new_ip"]   # use new IP as target
    else:
        state["ip"] = clean_ips[0] if clean_ips else None
    # ----------------------------------------------------------

    state["steps"].append(f"[ANALYZE] Classification: {state['classification']}")
    state["steps"].append(f"[ANALYZE] Domain: {state['domain']}")
    state["steps"].append(f"[ANALYZE] IP: {state['ip']}")

    return state


def dns_add_node(state: TicketState):

    if not state["domain"] or not state["ip"]:
        state["steps"].append("[DNS_ADD] Missing domain or IP.")
        state["success"] = False
        return state

    # -------- PRECHECK --------
    state["steps"].append(SECTION_PRECHECK)
    state["steps"].append(
        f"[PRECHECK] Checking if {state['domain']} -> {state['ip']} exists"
    )

    exists, ips, dig_output = precheck_domain(state["domain"])

    ips = [ip.strip() for ip in ips]
    state_ip = state["ip"].strip() if state["ip"] else None

# Always show DIG output first
    state["steps"].append(dig_output)

    if exists and state_ip in ips:
        state["steps"].append("[PRECHECK] Record already exists in DNS.")
        state["steps"].append("[INFO] DNS already correctly configured. No action required.")
        state["success"] = True
        state["action"] = "NO_ACTION"
        return state

    state["steps"].append("[PRECHECK] Record does not exist.")
    state["steps"].append("[INFO] Proceeding to add.")

    # -------- ACTION --------
    state["steps"].append(SECTION_ACTION)
    state["steps"].append(
        f"[DNS_ADD] Adding {state['domain']} -> {state['ip']}"
    )

    ok, msg = add_dns(state["domain"], state["ip"])
    state["steps"].append(f"[DNS_ADD] {msg}")

    state["success"] = ok
    return state




def dns_update_node(state: TicketState):

    new_ip = state.get("new_ip") or state.get("ip")
    old_ip_requested = state.get("old_ip")

    # -------- PRECHECK --------
    state["steps"].append(SECTION_PRECHECK)
    state["steps"].append(
        f"[PRECHECK] Checking existing DNS for {state['domain']}"
    )

    exists, current_ips, dig_output = precheck_domain(state["domain"])

    current_ips = [ip.strip() for ip in current_ips if ip]
    state["steps"].append(dig_output)

    if not exists:
        state["steps"].append("[PRECHECK] Domain not found in DNS.")
        state["success"] = False
        return state

    if not new_ip:
        state["steps"].append("[PRECHECK] No new IP provided for update.")
        state["success"] = False
        return state

    # 🔐 STRICT VALIDATION
    if old_ip_requested and old_ip_requested not in current_ips:
        state["steps"].append(
            f"[SAFETY] Existing DNS IP mismatch. "
            f"Expected old IP: {old_ip_requested}, "
            f"Found: {current_ips}"
        )
        state["success"] = False
        return state

    if new_ip in current_ips:
        state["steps"].append("[PRECHECK] New IP already present. No update needed.")
        state["steps"].append("[INFO] DNS already correctly configured.")
        state["success"] = True
        return state

    old_ip_actual = current_ips[0] if current_ips else "(no existing A record)"

    # -------- ACTION --------
    state["steps"].append(SECTION_ACTION)
    state["steps"].append(
        f"[DNS_UPDATE] Updating {state['domain']} from {old_ip_actual} -> {new_ip}"
    )

    ok, msg = update_dns(state["domain"], new_ip)
    state["steps"].append(f"[DNS_UPDATE] {msg}")

    state["success"] = ok
    return state



def dns_delete_node(state: TicketState):

    # -------- PRECHECK --------
    state["steps"].append(SECTION_PRECHECK)
    state["steps"].append(
        f"[PRECHECK] Checking DNS for {state['domain']}"
    )

    exists, ips, dig_output = precheck_domain(state["domain"])

# Always show DIG output first
    state["steps"].append(dig_output)

    if not exists:
        state["steps"].append("[PRECHECK] Record not found in DNS.")
        state["steps"].append("[INFO] Nothing to delete. No action required.")

        state["success"] = True
        state["action"] = "NO_ACTION"
        return state

    state["steps"].append("[PRECHECK] Record found.")
    state["steps"].append("[INFO] Proceeding to delete.")

    # -------- ACTION --------
    state["steps"].append(SECTION_ACTION)
    state["steps"].append(
        f"[DNS_DELETE] Deleting {state['domain']} (IPs: {ips})"
    )

    ok, msg = delete_dns(state["domain"])
    state["steps"].append(f"[DNS_DELETE] {msg}")

    state["success"] = ok
    return state




def postcheck_node(state: TicketState):

    state["steps"].append(f"[POSTCHECK] Verifying DNS resolution for {state['domain']}")

    ok, dig_output = postcheck_domain(state["domain"])
    state["steps"].append(dig_output)

    classification = state["classification"]

    # -------- STRICT LOGIC FOR DELETE --------
    if classification == "DNS_DELETE":
        exists = _dns_a_record_exists(dig_output, state["domain"])

        if exists:
            state["steps"].append("[POSTCHECK] Record still exists after delete.")
            state["success"] = False
        else:
            state["steps"].append("[POSTCHECK] Record successfully removed.")
            state["success"] = True

        return state

    # -------- NORMAL LOGIC FOR ADD / UPDATE --------
    state["success"] = ok

    if not ok:
        state["steps"].append(
            "[POSTCHECK] Verification failed. Ticket will not be resolved."
        )

    return state




def resolve_node(state: TicketState):

    state["steps"].append(SECTION_RESOLVE)

    if not state["success"]:
        state["steps"].append(
            "[RESOLVE] Postcheck failed. Ticket NOT resolved."
        )
        return state

    classification = state["classification"]
    domain = state["domain"]
    ip = state["ip"]

    if classification == "DNS_ADD":
        summary = (
            f"DNS record added successfully.\n\n"
            f"Domain: {domain}\n"
            f"IP: {ip}"
        )

    elif classification == "DNS_UPDATE":
        summary = (
            f"DNS record updated successfully.\n\n"
            f"Domain: {domain}\n"
            f"New IP: {ip}"
        )

    elif classification == "DNS_DELETE":
        summary = (
            f"DNS record deleted successfully.\n\n"
            f"Domain: {domain}"
        )

    else:
        summary = "Ticket reviewed. No DNS action performed."

    resolve_ticket(state["ticket"]["sys_id"], summary)
    state["steps"].append("[RESOLVE] Ticket resolved successfully.")

    return state




# -----------------------------
# ROUTER
# -----------------------------
def route_by_type(state: TicketState):
    return state["classification"]

# -----------------------------
# GRAPH BUILD
# -----------------------------
graph = StateGraph(TicketState)

graph.set_entry_point("analyze")

graph.add_node("analyze", analyze_node)
graph.add_node("dns_add", dns_add_node)
graph.add_node("dns_update", dns_update_node)
graph.add_node("dns_delete", dns_delete_node)
graph.add_node("postcheck", postcheck_node)
graph.add_node("resolve", resolve_node)

graph.add_conditional_edges(
    "analyze",
    route_by_type,
    {
        "DNS_ADD": "dns_add",
        "DNS_UPDATE": "dns_update",
        "DNS_DELETE": "dns_delete",
        "NON_DNS": "resolve"
    }
)

graph.add_edge("dns_add", "postcheck")
graph.add_edge("dns_update", "postcheck")
graph.add_edge("dns_delete", "postcheck")
def postcheck_router(state: TicketState):
    return "SUCCESS" if state["success"] else "FAIL"

graph.add_conditional_edges(
    "postcheck",
    postcheck_router,
    {
        "SUCCESS": "resolve",
        "FAIL": END
    }
)

graph.add_edge("resolve", END)

app = graph.compile()

# -----------------------------
# TICKET PROCESSOR
# -----------------------------
def process_ticket(ticket):
    state = {
    "ticket": ticket,
    "classification": "",
    "domain": None,
    "ip": None,
    "domains": [],
    "ips": [],
    "old_ip": None,         
    "new_ip": None,         
    "steps": [f"[START] Ticket {ticket['number']} processing started"],
    "success": False
}

    final_state = app.invoke(state)   

    output = "\n".join(final_state["steps"])
    return ticket["number"], output

import re

def _dns_a_record_exists(dig_output: str, domain: str) -> bool:
    """
    Return True ONLY if an A record exists in ANSWER SECTION
    """
    if "ANSWER SECTION" not in dig_output:
        return False

    pattern = rf"{domain}\.\s+\d+\s+IN\s+A\s+\d+\.\d+\.\d+\.\d+"
    return bool(re.search(pattern, dig_output))
# -----------------------------
# RUNNER WITH CONCURRENCY
# -----------------------------
def run():
    tickets = fetch_tickets()
    if not tickets:
        print("[INFO] No tickets found for caller Giridharan.")
        return

    print(f"[INFO] Fetched {len(tickets)} tickets for Giridharan.\n")

    MAX_WORKERS = 5
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_to_ticket = {executor.submit(process_ticket, t): t for t in tickets}

        for future in as_completed(future_to_ticket):
            ticket_number, output = future.result()
            print(f"\n--- Ticket {ticket_number} Output ---")
            print(output)
            print(f"--- End of Ticket {ticket_number} ---\n")

if __name__ == "__main__":
    run()
