 

SERVICENOW_INSTANCE = "https://dev270315.service-now.com"
SERVICENOW_USER = "admin"
SERVICENOW_PASS = "Cj$yD6c-rC2P"

CALLER_NAME = "Giridharan"
TABLE = "incident"
